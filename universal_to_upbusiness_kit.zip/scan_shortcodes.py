#!/usr/bin/env python3
import os, re, sys, json
from collections import Counter, defaultdict

if len(sys.argv) < 2:
    print("Usage: python scan_shortcodes.py /path/to/hugo-site/content")
    sys.exit(1)

content_dir = sys.argv[1]
name_re = re.compile(r"{{<\s*([a-zA-Z0-9_-]+)\b")

counts = Counter()
files_by_shortcode = defaultdict(list)

for base, _, files in os.walk(content_dir):
    for fn in files:
        if not fn.lower().endswith(('.md', '.markdown', '.html')):
            continue
        p = os.path.join(base, fn)
        try:
            with open(p, "r", encoding="utf-8") as f:
                text = f.read()
        except Exception:
            continue
        for m in name_re.finditer(text):
            sc = m.group(1)
            counts[sc] += 1
            files_by_shortcode[sc].append(os.path.relpath(p, content_dir))

print("\n# Shortcode frequency in content/\n")
for sc, n in counts.most_common():
    print(f"{sc}: {n}")

# Write a stub mapping JSON (old -> same) to help fill the migration map
stub = [{"from": sc, "to": sc, "param_map": {}} for sc in counts.keys()]
with open("stub_shortcodes_map.json", "w", encoding="utf-8") as f:
    json.dump(stub, f, indent=2)

print("\nWrote stub_shortcodes_map.json in current directory. Edit this and merge into your mapping JSON.")
